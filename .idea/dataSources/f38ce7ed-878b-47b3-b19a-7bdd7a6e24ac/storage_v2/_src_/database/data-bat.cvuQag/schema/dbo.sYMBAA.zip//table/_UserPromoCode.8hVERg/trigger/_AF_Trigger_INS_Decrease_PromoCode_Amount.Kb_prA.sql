CREATE TRIGGER _AF_Trigger_INS_Decrease_PromoCode_Amount
ON _UserPromoCode
AFTER INSERT
AS
DECLARE @promo_id INT
SET @promo_id = (SELECT INSERTED.promo_code_id FROM INSERTED)
IF (SELECT quantity FROM _PromoCode WHERE _PromoCode.id = @promo_id) > 0
BEGIN
    UPDATE _PromoCode
    SET quantity = quantity - 1
    WHERE _PromoCode.id = @promo_id
END
ELSE
BEGIN
    RAISERROR ('This promocode is not available yet', 16, 1)
    ROLLBACK TRANSACTION
    RETURN 
END;
GO

