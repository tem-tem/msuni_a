CREATE VIEW _PromoCodeReport
AS
SELECT
    _PromoCode.id,
    code,
    quantity,
    (tag + ' (' + CAST(lvl AS NVARCHAR) + ')') as 'access lvl'
FROM _PromoCode
INNER JOIN _Subscription ON subscription_id = _Subscription.id
INNER JOIN _AccessLevel ON _Subscription.access_level_id = _AccessLevel.id

-- Viev UserPromoCode
GO

