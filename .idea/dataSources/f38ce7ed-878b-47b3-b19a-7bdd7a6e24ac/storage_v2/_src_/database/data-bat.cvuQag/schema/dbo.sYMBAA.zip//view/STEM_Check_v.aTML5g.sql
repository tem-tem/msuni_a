
--show all checks
CREATE view STEM_Check_v
AS
select 
    STEM_Check.id,
    user_login as 'User',
    total_price as 'Total price'
from STEM_Check
inner join STEM_User on STEM_User.id = user_id

GO

