--show all games
create VIEW STEM_Game_v
as 
select * from STEM_Game;

GO

