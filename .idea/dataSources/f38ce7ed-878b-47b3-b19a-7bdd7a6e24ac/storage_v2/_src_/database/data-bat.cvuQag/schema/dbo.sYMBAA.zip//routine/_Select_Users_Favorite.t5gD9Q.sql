-- Выбрать все любимые фильмы пользователя с указанной почтой
CREATE PROCEDURE _Select_Users_Favorite @email VARCHAR(100)
AS
BEGIN
    SELECT
        title,
        release_date,
        watched,
        want_to_watch,
        is_favorite,
        liked
    FROM _Movie,
        _User,
        _MovieCard
    WHERE email = @email
    AND is_favorite = 1
    AND _Movie.id = _MovieCard.movie_id
    AND _User.id = _MovieCard.user_id
END;
GO

