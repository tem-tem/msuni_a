CREATE VIEW _MovieMemberReport
AS
SELECT
    _MovieMember.id,
    (title + ' (' + CAST(release_date AS NVARCHAR) + ')') as 'movie',
    (first_name + ' ' + last_name + ' (' + role_in_movie + ')') as 'member'
FROM _MovieMember
INNER JOIN _Movie ON _MovieMember.movie_id = _Movie.id
INNER JOIN _Member ON _MovieMember.member_id = _Member.id;

-- View MovieGenre
GO

