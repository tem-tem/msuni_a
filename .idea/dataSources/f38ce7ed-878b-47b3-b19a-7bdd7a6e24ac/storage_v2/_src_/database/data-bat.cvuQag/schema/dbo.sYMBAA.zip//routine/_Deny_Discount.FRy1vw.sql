-- Отменить скидку на подписки
CREATE PROCEDURE _Deny_Discount @discount_percent FLOAT
AS
BEGIN
    UPDATE _Subscription
    SET price = price / (1 - @discount_percent/100)
END;
GO

