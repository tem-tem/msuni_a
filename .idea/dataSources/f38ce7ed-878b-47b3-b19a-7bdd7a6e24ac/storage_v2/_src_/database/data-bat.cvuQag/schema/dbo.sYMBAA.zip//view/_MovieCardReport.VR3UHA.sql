CREATE VIEW _MovieCardReport
AS
SELECT 
    _MovieCard.id,
    email,
    (title + ' (' + CAST(release_date AS NVARCHAR) + ')') as 'movie',
    watched,
    want_to_watch,
    is_favorite,
    liked
FROM _MovieCard
INNER JOIN _User ON _MovieCard.user_id = _User.id
INNER JOIN _Movie ON _MovieCard.movie_id = _Movie.id

-- View PromoCode
GO

