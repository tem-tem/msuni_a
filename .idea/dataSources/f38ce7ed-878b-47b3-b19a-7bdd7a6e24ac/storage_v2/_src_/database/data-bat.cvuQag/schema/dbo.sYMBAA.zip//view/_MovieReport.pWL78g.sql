-- View Movie
CREATE VIEW _MovieReport
AS
SELECT 
    _Movie.id, 
    title,
    duration,
    movie_description,
    release_date,
    poster,
    trailer_url,
    suggested,
    (tag + ' (' + CAST(lvl AS NVARCHAR) + ')') as 'access lvl'
FROM _Movie
INNER JOIN _AccessLevel ON _Movie.access_lvl_id = _AccessLevel.id;

-- View MovieMember
GO

