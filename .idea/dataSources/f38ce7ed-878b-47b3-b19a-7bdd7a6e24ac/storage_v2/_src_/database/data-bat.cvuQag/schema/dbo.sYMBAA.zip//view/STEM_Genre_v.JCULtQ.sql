
--show all genres
CREATE VIEW STEM_Genre_v
AS
select * from STEM_Genre;

GO

