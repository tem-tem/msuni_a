
--show games in check
create procedure STEM_Select_games_in_check @check_no INT
AS
begin 
    select game_id, title
    from STEM_CheckPosition
    inner JOIN STEM_Game on STEM_Game.id = STEM_CheckPosition.game_id
    where check_id = @check_no
end;
GO

