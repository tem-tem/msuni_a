
--show all vids
CREATE view STEM_Vid_v
as
select 
    STEM_Vid.id,
    title,
    link 
from STEM_Vid
inner join STEM_Game on STEM_Game.id = game_id

GO

