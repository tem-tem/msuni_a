CREATE VIEW _SubscriptionReport
AS
SELECT
    _Subscription.id,
    (tag + ' (' + CAST(lvl AS NVARCHAR) + ')') as 'access lvl',
    duration,
    price,
    visible
FROM _Subscription
INNER JOIN _AccessLevel ON access_level_id = _AccessLevel.id;

-- View User
GO

