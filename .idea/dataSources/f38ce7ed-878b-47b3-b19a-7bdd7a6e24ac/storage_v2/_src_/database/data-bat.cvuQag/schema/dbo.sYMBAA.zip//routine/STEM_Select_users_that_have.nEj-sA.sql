
--show users that have this specific game
create procedure STEM_Select_users_that_have @game_title VARCHAR(100)
AS
BEGIN
    select user_login
    from STEM_User
    inner join STEM_UserGame on STEM_UserGame.user_id = stem_user.id
    inner join STEM_Game on STEM_UserGame.game_id = STEM_Game.id
    where title = @game_title
end;

GO

