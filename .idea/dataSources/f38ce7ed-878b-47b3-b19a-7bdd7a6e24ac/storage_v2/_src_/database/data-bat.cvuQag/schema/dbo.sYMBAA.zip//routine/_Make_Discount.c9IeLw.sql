-- STORED PROCEDURES
-- Снизить цену на подписки на указанный процент
CREATE PROCEDURE _Make_Discount @discount_percent FLOAT
AS
BEGIN
    UPDATE _Subscription
    SET price = price - price*(@discount_percent/100)
END;
GO

