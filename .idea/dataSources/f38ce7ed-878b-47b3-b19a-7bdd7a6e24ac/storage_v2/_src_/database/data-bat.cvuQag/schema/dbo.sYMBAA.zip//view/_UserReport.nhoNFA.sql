CREATE VIEW _UserReport
AS
SELECT
    _User.id,
    email,
    first_name,
    last_name,
    activated,
    is_staff,
    subscribed_date,
    (tag + ' (' + CAST(lvl AS NVARCHAR) + ') / ' + CAST(duration AS NVARCHAR) + ' (days)') as 'subscription'
FROM _User
INNER JOIN _Subscription ON subscription_id = _Subscription.id
INNER JOIN _AccessLevel ON _Subscription.access_level_id = _AccessLevel.id
GO

