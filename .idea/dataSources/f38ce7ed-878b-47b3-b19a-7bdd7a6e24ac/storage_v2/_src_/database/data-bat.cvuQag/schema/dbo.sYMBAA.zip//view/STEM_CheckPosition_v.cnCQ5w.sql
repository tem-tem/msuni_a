
--show all check_positions
CREATE view STEM_CheckPosition_v
AS
select 
    STEM_CheckPosition.id,
    title,
    check_id 
from STEM_CheckPosition
inner join STEM_Game on STEM_Game.id = game_id

GO

