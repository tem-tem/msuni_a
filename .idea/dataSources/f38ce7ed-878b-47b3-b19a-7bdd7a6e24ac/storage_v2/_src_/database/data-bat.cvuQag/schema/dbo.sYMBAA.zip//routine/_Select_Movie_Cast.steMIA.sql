-- Выбрать всех участников указанного фильма
CREATE PROCEDURE _Select_Movie_Cast @title NVARCHAR(150)
AS
BEGIN
    SELECT
        first_name,
        last_name,
        role_in_movie
    FROM _Member,
         _MovieMember,
         _Movie
    WHERE _Movie.title = @title
    AND _Movie.id = _MovieMember.movie_id
    AND _Member.id = _MovieMember.member_id
END;
GO

