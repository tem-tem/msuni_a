CREATE TRIGGER TProducts ON Orders
AFTER UPDATE
AS
BEGIN
	declare @order_id INT
	declare @product_id INT

	set @order_id = (select INSERTED.ID_Order from inserted)
	set @product_id = (select ID_Product 
						from ProductsToOrders
						where ID_Order = @order_id)
	UPDATE Products 
	set Quantity_Pr = Quantity_Pr - 1
	where ID_Product = @product_id
 
END
GO

