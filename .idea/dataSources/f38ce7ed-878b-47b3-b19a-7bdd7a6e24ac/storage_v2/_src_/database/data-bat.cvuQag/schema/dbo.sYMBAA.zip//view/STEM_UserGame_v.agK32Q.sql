
--show usergame
CREATE view STEM_UserGame_v
AS
select 
    STEM_UserGame.id,
    title as 'Game title',
    user_login as 'User' 
from STEM_UserGame
inner join STEM_Game on STEM_UserGame.game_id = STEM_Game.id
inner join STEM_User on STEM_UserGame.user_id = STEM_User.id

GO

