CREATE VIEW _UserPromoCodeReport
AS
SELECT
    _UserPromoCode.id,
    email,
    code,
    is_active
FROM _UserPromoCode
INNER JOIN _User ON user_id = _User.id
INNER JOIN _PromoCode ON promo_code_id = _PromoCode.id
GO

