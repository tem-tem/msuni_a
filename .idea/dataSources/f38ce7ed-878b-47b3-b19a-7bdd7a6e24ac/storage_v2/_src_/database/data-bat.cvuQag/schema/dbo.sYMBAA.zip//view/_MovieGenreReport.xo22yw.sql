CREATE VIEW _MovieGenreReport
AS
SELECT
    _MovieGenre.id,
    (title + ' (' + CAST(release_date AS NVARCHAR) + ')') as 'movie',
    tag
FROM _MovieGenre
INNER JOIN _Movie ON _MovieGenre.movie_id = _Movie.id
INNER JOIN _Genre ON _MovieGenre.genre_id = _Genre.id;

-- View Image
GO

