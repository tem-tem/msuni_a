
--show all gameGenres
CREATE VIEW STEM_GameGenre_v
AS
    select STEM_GameGenre.id,
    title as 'Game title',
    genre_name as 'Genre'
from STEM_Game
inner join STEM_GameGenre on STEM_GameGenre.game_id = STEM_Game.id
inner join STEM_Genre on STEM_Genre.id = STEM_GameGenre.genre_id

GO

