
--show games of a specific genre
create procedure STEM_Select_genre_games @genre VARCHAR(50)
AS
begin
    select STEM_Game.id, title, game_description, price
    from STEM_Game
    inner join STEM_GameGenre on STEM_GameGenre.game_id = STEM_Game.id
    inner join STEM_Genre on STEM_Genre.id = STEM_GameGenre.genre_id
    where genre_name = @genre
end;

GO

