
--show genres by popularity
CREATE view STEM_Pop_Genres
as
select genre_name, count(genre_id) as games
from STEM_GameGenre
inner join STEM_Genre on STEM_Genre.id = STEM_GameGenre.genre_id
group by genre_name

GO

