
--show genres of this specific game
create PROCEDURE STEM_Select_genres_of @game_title VARCHAR(100)
AS
BEGIN
    select genre_name
    from STEM_GameGenre
    inner join STEM_Genre on STEM_Genre.id = STEM_GameGenre.genre_id
    inner join STEM_Game on STEM_GameGenre.game_id = STEM_Game.id
    where title = @game_title
end;

GO

