
--show all pics
CREATE view STEM_Pic_v
as 
select 
    STEM_Pic.id,
    title,
    link 
from STEM_Pic
inner join STEM_Game on STEM_Game.id = game_id

GO

