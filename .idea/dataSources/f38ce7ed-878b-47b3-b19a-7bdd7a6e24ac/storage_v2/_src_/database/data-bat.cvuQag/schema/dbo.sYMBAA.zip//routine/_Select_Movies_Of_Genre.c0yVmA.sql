-- Выбрать все фильмы переданного жанра
CREATE PROCEDURE _Select_Movies_Of_Genre @genre_tag NVARCHAR(100)
AS
BEGIN
    SELECT
        title,
        release_date,
        duration
    FROM _Movie,
         _MovieGenre
    WHERE _Movie.id = _MovieGenre.movie_id
    AND _MovieGenre.genre_id = (SELECT id FROM _Genre WHERE tag = @genre_tag)
END;
GO

