
--show most liked games
CREATE view STEM_Likes_v
as
select 
    game_id,
    title,
    count(liked) as likes
from STEM_UserGame
inner join STEM_Game on STEM_UserGame.game_id = STEM_Game.id
where liked = 1
group by title, game_id

GO

