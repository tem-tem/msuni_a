
--show all users
CREATE view STEM_User_v
as 
select 
    id,
    user_login,
    email
from STEM_User;

GO

