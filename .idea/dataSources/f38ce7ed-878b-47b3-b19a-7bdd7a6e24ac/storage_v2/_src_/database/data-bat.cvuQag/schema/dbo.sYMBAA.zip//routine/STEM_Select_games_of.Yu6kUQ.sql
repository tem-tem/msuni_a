
--show games of a specific user
create procedure STEM_Select_games_of @user_login VARCHAR(40)
AS
BEGIN
    select STEM_Game.id, title
    from STEM_Game
    inner join STEM_UserGame on STEM_UserGame.game_id = STEM_Game.id
    inner join STEM_User on STEM_UserGame.user_id = STEM_User.id
    where user_login = @user_login
end;

GO

