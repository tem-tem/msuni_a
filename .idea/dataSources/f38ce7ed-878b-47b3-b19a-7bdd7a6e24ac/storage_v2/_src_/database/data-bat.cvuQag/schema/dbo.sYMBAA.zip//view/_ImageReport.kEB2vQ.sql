CREATE VIEW _ImageReport
AS
SELECT
    _Image.id,
    (title + ' (' + CAST(release_date AS NVARCHAR) + ')') as 'movie',
    [file]
FROM _Image
INNER JOIN _Movie ON movie_id = _Movie.id;
GO

