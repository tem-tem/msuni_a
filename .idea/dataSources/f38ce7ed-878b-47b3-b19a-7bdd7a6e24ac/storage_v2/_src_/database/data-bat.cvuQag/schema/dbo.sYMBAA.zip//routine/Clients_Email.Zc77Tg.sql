CREATE PROCEDURE Clients_Email @email VaRCHAR(max)
as
begin
	print @email
	select * from Clients where Email_Cl=@email
end
GO

