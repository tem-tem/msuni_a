
--show download times of each game
CREATE view STEM_Download_Times
as
select title, count(check_id) as downloads
from STEM_CheckPosition
inner join STEM_Game on STEM_Game.id = game_id
group by title

GO

