CREATE TRIGGER check_id ON STEM_CheckPosition
    AFTER INSERT, UPDATE, DELETE
    AS
    BEGIN
        DECLARE @check_id INT
        DECLARE @total FLOAT
        
        SET @check_id = (SELECT INSERTED.check_id FROM INSERTED)
        SET @total = (SELECT sum(price)
                        FROM STEM_Game
                        INNER JOIN STEM_CheckPosition ON STEM_Game.id = STEM_CheckPosition.game_id
                        WHERE STEM_CheckPosition.check_id = @check_id
                        group by STEM_CheckPosition.check_id
                        )

        UPDATE STEM_Check
        SET total_price = @total
        WHERE STEM_Check.id = @check_id
    END
GO

